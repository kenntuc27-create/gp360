﻿import { AppShell } from "@/components/AppShell";
import { createFileRoute } from "@tanstack/react-router";
import {
  listarBackups,
  criarSnapshot,
  criarSnapshotGit,
  excluirBackup,
  listarTagsGit
} from "@/lib/backups.functions";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/backups")({
  component: BackupsPage,
});

function BackupsPage() {

  const [backups, setBackups] = useState<any[]>([]);
  const [tagsGit, setTagsGit] = useState<string[]>([]);
  const [processando, setProcessando] = useState(false);
  const [statusSnapshot, setStatusSnapshot] = useState("Pronto");

  useEffect(() => {

    listarBackups()
      .then((dados:any) => setBackups(dados || []))
      .catch(console.error);

    listarTagsGit()
      .then((dados:any) => setTagsGit(dados || []))
      .catch(console.error);

  }, []);

  const ultimoBackup =
    backups.length > 0
      ? new Date(backups[0].data).toLocaleString("pt-BR")
      : "--";

  return (
    <AppShell title="Backups 3K360">

      <div className="p-6">

        <h1 className="text-3xl font-bold">
          Backups 3K360
        </h1>

        <p className="mt-2 opacity-70">
          Central de snapshots e restauração
        </p>

        <div className="mt-4 border rounded-xl p-4 bg-muted/30">
          <div className="text-sm opacity-70">Status do Snapshot</div>
          <div className="text-lg font-semibold mt-1">
            {processando ? "🟡 " : "🟢 "}{statusSnapshot}
          </div>
        </div>

        <button
          onClick={async () => {

            if (processando) return;

            setProcessando(true);
            setStatusSnapshot("Criando Snapshot GitHub...");

            await new Promise(r => setTimeout(r, 100));

            try {

              await criarSnapshotGit();

              setStatusSnapshot("Criando Backup Local...");
              await criarSnapshot();

              setStatusSnapshot("Atualizando Painel...");

              const tags = await listarTagsGit();
              setTagsGit(tags || []);

              const dados = await listarBackups();
              setBackups(dados || []);

              setStatusSnapshot("Snapshot concluído");
              alert("Snapshot criado com sucesso");
              setProcessando(false);

            } catch (e:any) {

              console.error(e);
              setStatusSnapshot("Erro ao criar snapshot");
                alert("Erro ao criar snapshot");
                setProcessando(false);

            }
          }}
          className="mt-4 border rounded px-4 py-2 cursor-pointer"
        >
          Criar Snapshot
        </button>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">

          <div className="border rounded-xl p-4">
            <div className="text-sm opacity-70">
              Snapshots GitHub
            </div>

            <div className="text-3xl font-bold">
              {tagsGit.length}
            </div>
          </div>

          <div className="border rounded-xl p-4">
            <div className="text-sm opacity-70">
              Arquivos Locais
            </div>

            <div className="text-3xl font-bold">
              {backups.length}
            </div>
          </div>

          <div className="border rounded-xl p-4">
            <div className="text-sm opacity-70">
              Último Backup
            </div>

            <div className="font-semibold">
              {ultimoBackup}
            </div>
          </div>

        </div>

        <div className="mt-10">

          <h2 className="text-xl font-bold mb-4">
            Snapshots GitHub
          </h2>

          <div className="space-y-3">

            {tagsGit.map((tag, i) => (

              <div
                key={i}
                className="border rounded-xl p-4 flex items-center justify-between"
              >
                <div>
                  {tag}
                </div>

                <div className="mt-4 border rounded-xl p-4 bg-muted/30">
          <div className="text-sm opacity-70">Status do Snapshot</div>
          <div className="text-lg font-semibold mt-1">
            {processando ? "🟡 " : "🟢 "}{statusSnapshot}
          </div>
        </div>

        <button
                  className="border rounded px-3 py-1"
                >
                  Restaurar
                </button>

              </div>

            ))}

          </div>

        </div>

        <div className="mt-10">

          <h2 className="text-xl font-bold mb-4">
            Arquivos Locais
          </h2>

          <div className="space-y-4">

            {backups.map((b, i) => (

              <div
                key={i}
                className="border rounded-xl p-4"
              >
                <div className="font-semibold">
                  {b.nome}
                </div>

                <div className="text-sm opacity-70">
                  {b.tamanho} MB
                </div>

                <div className="text-sm opacity-70">
                  {new Date(b.data).toLocaleString("pt-BR")}
                </div>

                <div className="mt-3 flex gap-2">

                  <a
                    href={"/backups/snapshots/" + b.nome}
                    target="_blank"
                    className="border rounded px-3 py-1"
                  >
                    Download
                  </a>

                  <div className="mt-4 border rounded-xl p-4 bg-muted/30">
          <div className="text-sm opacity-70">Status do Snapshot</div>
          <div className="text-lg font-semibold mt-1">
            {processando ? "🟡 " : "🟢 "}{statusSnapshot}
          </div>
        </div>

        <button
                    onClick={async () => {

                      if (!confirm(`Excluir ${b.nome}?`))
                        return;

                      await excluirBackup({
                        data: {
                          nome: b.nome
                        }
                      });

                      const dados =
                        await listarBackups();

                      setBackups(dados || []);

                    }}
                    className="border rounded px-3 py-1 text-red-500"
                  >
                    Excluir
                  </button>

                </div>

              </div>

            ))}

          </div>

        </div>

      </div>

    </AppShell>
  );
}




